// minimal interactivity
document.addEventListener('DOMContentLoaded',()=>{console.log('Admin frontend loaded')});